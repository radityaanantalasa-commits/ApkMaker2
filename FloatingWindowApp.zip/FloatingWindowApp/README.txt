BUILD APK (untuk tes di HP):
  Build > Build APK(s)

BUILD AAB (untuk Play Store):
  Build > Generate Signed Bundle / APK > Android App Bundle
  Buat keystore baru, SIMPAN file keystore + password dengan aman.

Target SDK sudah 36 (syarat Play Store sejak 31 Agustus 2026).
Ganti applicationId (com.example.floatwin) dengan ID unikmu sebelum upload.
