package com.example.floatwin

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

// ===== MainActivity: minta izin overlay lalu jalankan service =====
class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!Settings.canDrawOverlays(this)) {
            startActivity(
                Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
            )
        } else {
            startForegroundService(Intent(this, FloatingService::class.java))
            finish()
        }
    }

    override fun onResume() {
        super.onResume()
        if (Settings.canDrawOverlays(this)) {
            startForegroundService(Intent(this, FloatingService::class.java))
            finish()
        }
    }
}

// ===== FloatingService: jendela yang bisa digeser & diubah ukurannya =====
class FloatingService : Service() {
    private lateinit var wm: WindowManager
    private var root: View? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(1, buildNotification())
        if (root == null) showWindow()
        return START_NOT_STICKY
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("float", "Jendela Mengambang", NotificationManager.IMPORTANCE_LOW)
        )
        return Notification.Builder(this, "float")
            .setContentTitle("Jendela mengambang aktif")
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .build()
    }

    private fun showWindow() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val d = resources.displayMetrics.density

        val params = WindowManager.LayoutParams(
            (280 * d).toInt(), (220 * d).toInt(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 100; y = 200
        }

        // Title bar (tarik untuk geser)
        val title = TextView(this).apply {
            text = "Jendela 1"
            setTextColor(Color.WHITE)
            setPadding((12 * d).toInt(), (8 * d).toInt(), 0, (8 * d).toInt())
        }
        val close = Button(this).apply {
            text = "X"
            setOnClickListener { stopSelf() }
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.parseColor("#1565C0"))
            addView(title, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(close, LinearLayout.LayoutParams((48 * d).toInt(), (40 * d).toInt()))
        }

        // Isi jendela
        val body = TextView(this).apply {
            text = "Isi jendela di sini.\nGeser lewat judul, ubah ukuran lewat pojok kanan bawah."
            setTextColor(Color.BLACK)
            setPadding((12 * d).toInt(), (12 * d).toInt(), (12 * d).toInt(), 0)
        }

        // Handle resize
        val handle = TextView(this).apply {
            text = "◢"
            gravity = Gravity.END
            setPadding(0, 0, (8 * d).toInt(), 0)
        }

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#F5F5F5"))
            addView(bar)
            addView(body, LinearLayout.LayoutParams(-1, 0, 1f))
            addView(handle, LinearLayout.LayoutParams(-1, -2))
        }

        // Geser
        var startX = 0; var startY = 0; var touchX = 0f; var touchY = 0f
        bar.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x; startY = params.y
                    touchX = e.rawX; touchY = e.rawY
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX + (e.rawX - touchX).toInt()
                    params.y = startY + (e.rawY - touchY).toInt()
                    wm.updateViewLayout(container, params)
                }
            }
            true
        }

        // Ubah ukuran
        var startW = 0; var startH = 0
        handle.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startW = params.width; startH = params.height
                    touchX = e.rawX; touchY = e.rawY
                }
                MotionEvent.ACTION_MOVE -> {
                    params.width = (startW + (e.rawX - touchX).toInt()).coerceAtLeast((160 * d).toInt())
                    params.height = (startH + (e.rawY - touchY).toInt()).coerceAtLeast((120 * d).toInt())
                    wm.updateViewLayout(container, params)
                }
            }
            true
        }

        root = container
        wm.addView(container, params)
    }

    override fun onDestroy() {
        root?.let { wm.removeView(it) }
        root = null
        super.onDestroy()
    }
}
